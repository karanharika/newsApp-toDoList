About the App:

App has total of three tabs:

i) Tab one is called: News List
	Click in the news to open details.
	Details for one or two news might not open because of the varition in JSON data being provided from the sourceAPI.

ii) Tab two is the default tab.

iii) Tab three contains To-Do-List:
	For To-Do List:

	1. Add text in the input box and click on Add button on right side of input.
	2. To update the view of Tasks in To-Do List:
		a) add next item then the view will be updated automatically, OR
		b) reload/refresh the page to view most recent added item in the To-Do List.
	3. Click in the trash button to delete the specific task.
	4. Click and hold the reorder icon on right side to drag to reorder the tasks in To-Do List.